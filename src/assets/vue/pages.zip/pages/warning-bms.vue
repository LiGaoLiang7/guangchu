<template>
  <f7-page>
    <f7-navbar title="BMS告警信息" back-link="Back" href="/params/"></f7-navbar>
    <f7-list class="media-list">
      <f7-list-item v-for="(item, index) in datalist" :key="item.paramName">
        <span>{{item.paramName}}</span>
        <span class="params">{{gitstatusname(item.paramValue)}}</span>
        <em class="unit">{{item.unit}}</em>
      </f7-list-item>
    </f7-list>
  </f7-page>
</template>
<script>
import { f7Navbar, f7Page, f7BlockTitle } from 'framework7-vue';
  export default {
    props : {
      params : {
        type : Array,
        default : function(){
          return []
        }
      }
    },
    data : function(){
      return {
        datalist : [
          {paramName : "电池高电流放电",  paramValue : 1, unit : ""},
          {paramName : "电池高电流充电",  paramValue : 0, unit : ""},
          {paramName : "电池温度过低",    paramValue : 0, unit : ""},
          {paramName : "电池温度过高",    paramValue : 0, unit : ""},
          {paramName : "电池电压过低",    paramValue : 0, unit : ""},
          {paramName : "电池电压过高",    paramValue : 0, unit : ""},
        ]
      }
    },
    methods : {
      gitstatusname : function(num){
        return num == 1 ? "异常" : "正常"
      }
    },
    mounted : function(){
      // this.datalist =  this.params;
    },
    components: {
      f7Navbar,
      f7Page,
      f7BlockTitle
    },
  };
</script>


<style>
.media-list span{
    display: inline-block;
    width: 76%;
    text-align: left;
  }
  .media-list .params{
    display: inline;
    text-align: center;
    border: 1px solid #e2e2e2;
    height: 30px !important;
    border-radius: 9px;
    width: 20% !important;
  }
   .media-list span.params{
    width: 20%;
    display: inline-block;
    line-height: 30px;
  }
</style>